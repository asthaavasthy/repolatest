﻿using System.Collections.Generic;
using System.Text.Json.Serialization;



/// <summary>
///     Represents a chat message.
/// </summary>
/// <param name="Content"> The content of the chat message. </param>
/// <param name="Role"> The role of the chat message.</param>
namespace ImagetoTextConverterOpenAI.Models
{
    internal record ChatMessage(
    [property: JsonPropertyName("content")] IEnumerable<MessageContent> Content,
    [property: JsonPropertyName("role")] string Role = "user");


}
