﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SampleUI.Models;
using System.Collections.Generic;
using System.Diagnostics;
using ImagetoTextConverterOpenAI;
using ImagetoTextConverterOpenAI.Models;
using Microsoft.AspNetCore.Http.Json;
using Spectre.Console;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Amazon;
using Amazon.Translate;
using Amazon.Translate.Model;
using System.Threading.Tasks;
using System.IO;
using System;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Net.Http.Json;
using Tesseract;

using Multilinguism.Models;

namespace SampleUI.Controllers
{
   
    public class HomeController : Controller
    {
        string completionsEndpoint = "https://api.openai.com/v1/chat/completions";
        private readonly ILogger<HomeController> _logger;
        JsonSerializerOptions jsonOptions = new()
        {
            WriteIndented = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
        };
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var model = new AIGenerative
            {
                Languages = new List<SelectListItem>()
                {
                    new SelectListItem { Text = "Afrikaans", Value = "af" },
                    new SelectListItem { Text = "Albanian", Value = "sq" },
                    new SelectListItem { Text = "Amharic", Value = "am" },
                    new SelectListItem { Text = "Arabic", Value = "ar" },
                    new SelectListItem { Text = "Armenian", Value = "hy" },
                    new SelectListItem { Text = "Azerbaijani", Value = "az" },
                    new SelectListItem { Text = "Bengali", Value = "bn" },
                    new SelectListItem { Text = "Bosnian", Value = "bs" },
                    new SelectListItem { Text = "Bulgarian", Value = "bg" },
                    new SelectListItem { Text = "Catalan", Value = "ca" },
                    new SelectListItem { Text = "Chinese (Simplified)", Value = "zh" },
                    new SelectListItem { Text = "Chinese (Traditional)", Value = "zh-TW" },
                    new SelectListItem { Text = "Croatian", Value = "hr" },
                    new SelectListItem { Text = "Czech", Value = "cs" },
                    new SelectListItem { Text = "Danish", Value = "da" },
                    new SelectListItem { Text = "Dari", Value = "fa-AF" },
                    new SelectListItem { Text = "Dutch", Value = "nl" },
                    new SelectListItem { Text = "English", Value = "en" },
                    new SelectListItem { Text = "Estonian", Value = "et" },
                    new SelectListItem { Text = "Farsi (Persian)", Value = "fa" },
                    new SelectListItem { Text = "Filipino, Tagalog", Value = "tl" },
                    new SelectListItem { Text = "Finnish", Value = "fi" },
                    new SelectListItem { Text = "French", Value = "fr" },
                    new SelectListItem { Text = "French (Canada)", Value = "fr-CA" },
                    new SelectListItem { Text = "Georgian", Value = "af" },
                    new SelectListItem { Text = "German", Value = "de" },
                    new SelectListItem { Text = "Greek", Value = "el" },
                    new SelectListItem { Text = "Gujarati", Value = "gu" },
                    new SelectListItem { Text = "Haitian Creole", Value = "ht" },
                    new SelectListItem { Text = "Hausa", Value = "ha" },
                    new SelectListItem { Text = "Hebrew", Value = "he" },
                    new SelectListItem { Text = "Hindi", Value = "hi" },
                    new SelectListItem { Text = "Hungarian", Value = "hu" },
                    new SelectListItem { Text = "Icelandic", Value = "is" },
                    new SelectListItem { Text = "Indonesian", Value = "id" },
                    new SelectListItem { Text = "Irish", Value = "ga" },
                    new SelectListItem { Text = "Italian", Value = "it" },
                    new SelectListItem { Text = "Japanese", Value = "ja" },
                    new SelectListItem { Text = "Kannada", Value = "kn" },
                    new SelectListItem { Text = "Kazakh", Value = "kk" },
                    new SelectListItem { Text = "Korean", Value = "ko" },
                    new SelectListItem { Text = "Latvian", Value = "lv" },
                    new SelectListItem { Text = "Lithuanian", Value = "lt" },
                    new SelectListItem { Text = "Macedonian", Value = "mk" },
                    new SelectListItem { Text = "Malay", Value = "ms" },
                    new SelectListItem { Text = "Malayalam", Value = "ml" },
                    new SelectListItem { Text = "Maltese", Value = "mt" },
                    new SelectListItem { Text = "Marathi", Value = "mr" },
                    new SelectListItem { Text = "Mongolian", Value = "mn" },
                    new SelectListItem { Text = "Norwegian (Bokmål)", Value = "no" },
                    new SelectListItem { Text = "Pashto", Value = "ps" },
                    new SelectListItem { Text = "Polish", Value = "pl" },
                    new SelectListItem { Text = "Portuguese (Brazil)", Value = "pt" },
                    new SelectListItem { Text = "Portuguese (Portugal)", Value = "pt-PT" },
                    new SelectListItem { Text = "Punjabi", Value = "pa" },
                    new SelectListItem { Text = "Romanian", Value = "ro" },
                    new SelectListItem { Text = "Russian", Value = "ru" },
                    new SelectListItem { Text = "Serbian", Value = "sr" },
                    new SelectListItem { Text = "Sinhala", Value = "si" },
                    new SelectListItem { Text = "Slovak", Value = "sk" },
                    new SelectListItem { Text = "Slovenian", Value = "sl" },
                    new SelectListItem { Text = "Somali", Value = "so" },
                    new SelectListItem { Text = "Spanish", Value = "es" },
                    new SelectListItem { Text = "Spanish (Mexico)", Value = "es-MX" },
                    new SelectListItem { Text = "Swahili", Value = "sw" },
                    new SelectListItem { Text = "Swedish", Value = "sv" },
                    new SelectListItem { Text = "Tamil", Value = "ta" },
                    new SelectListItem { Text = "Telugu", Value = "te" },
                    new SelectListItem { Text = "Thai", Value = "th" },
                    new SelectListItem { Text = "Turkish", Value = "tr" },
                    new SelectListItem { Text = "Ukrainian", Value = "uk" },
                    new SelectListItem { Text = "Urdu", Value = "ur" },
                    new SelectListItem { Text = "Uzbek", Value = "uz" },
                    new SelectListItem { Text = "Vietnamese", Value = "vi" },
                    new SelectListItem { Text = "Welsh", Value = "cy" },

                },
                Language = "en"
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddView(AIGenerative objInfo)
        {
            if (!ModelState.IsValid)
            {
                // Check if the file has a valid extension

                
                objInfo.Languages = new List<SelectListItem>()
                {
                    new SelectListItem { Text = "Afrikaans", Value = "af" },
                    new SelectListItem { Text = "Albanian", Value = "sq" },
                    new SelectListItem { Text = "Amharic", Value = "am" },
                    new SelectListItem { Text = "Arabic", Value = "ar" },
                    new SelectListItem { Text = "Armenian", Value = "hy" },
                    new SelectListItem { Text = "Azerbaijani", Value = "az" },
                    new SelectListItem { Text = "Bengali", Value = "bn" },
                    new SelectListItem { Text = "Bosnian", Value = "bs" },
                    new SelectListItem { Text = "Bulgarian", Value = "bg" },
                    new SelectListItem { Text = "Catalan", Value = "ca" },
                    new SelectListItem { Text = "Chinese (Simplified)", Value = "zh" },
                    new SelectListItem { Text = "Chinese (Traditional)", Value = "zh-TW" },
                    new SelectListItem { Text = "Croatian", Value = "hr" },
                    new SelectListItem { Text = "Czech", Value = "cs" },
                    new SelectListItem { Text = "Danish", Value = "da" },
                    new SelectListItem { Text = "Dari", Value = "fa-AF" },
                    new SelectListItem { Text = "Dutch", Value = "nl" },
                    new SelectListItem { Text = "English", Value = "en" },
                    new SelectListItem { Text = "Estonian", Value = "et" },
                    new SelectListItem { Text = "Farsi (Persian)", Value = "fa" },
                    new SelectListItem { Text = "Filipino, Tagalog", Value = "tl" },
                    new SelectListItem { Text = "Finnish", Value = "fi" },
                    new SelectListItem { Text = "French", Value = "fr" },
                    new SelectListItem { Text = "French (Canada)", Value = "fr-CA" },
                    new SelectListItem { Text = "Georgian", Value = "af" },
                    new SelectListItem { Text = "German", Value = "de" },
                    new SelectListItem { Text = "Greek", Value = "el" },
                    new SelectListItem { Text = "Gujarati", Value = "gu" },
                    new SelectListItem { Text = "Haitian Creole", Value = "ht" },
                    new SelectListItem { Text = "Hausa", Value = "ha" },
                    new SelectListItem { Text = "Hebrew", Value = "he" },
                    new SelectListItem { Text = "Hindi", Value = "hi" },
                    new SelectListItem { Text = "Hungarian", Value = "hu" },
                    new SelectListItem { Text = "Icelandic", Value = "is" },
                    new SelectListItem { Text = "Indonesian", Value = "id" },
                    new SelectListItem { Text = "Irish", Value = "ga" },
                    new SelectListItem { Text = "Italian", Value = "it" },
                    new SelectListItem { Text = "Japanese", Value = "ja" },
                    new SelectListItem { Text = "Kannada", Value = "kn" },
                    new SelectListItem { Text = "Kazakh", Value = "kk" },
                    new SelectListItem { Text = "Korean", Value = "ko" },
                    new SelectListItem { Text = "Latvian", Value = "lv" },
                    new SelectListItem { Text = "Lithuanian", Value = "lt" },
                    new SelectListItem { Text = "Macedonian", Value = "mk" },
                    new SelectListItem { Text = "Malay", Value = "ms" },
                    new SelectListItem { Text = "Malayalam", Value = "ml" },
                    new SelectListItem { Text = "Maltese", Value = "mt" },
                    new SelectListItem { Text = "Marathi", Value = "mr" },
                    new SelectListItem { Text = "Mongolian", Value = "mn" },
                    new SelectListItem { Text = "Norwegian (Bokmål)", Value = "no" },
                    new SelectListItem { Text = "Pashto", Value = "ps" },
                    new SelectListItem { Text = "Polish", Value = "pl" },
                    new SelectListItem { Text = "Portuguese (Brazil)", Value = "pt" },
                    new SelectListItem { Text = "Portuguese (Portugal)", Value = "pt-PT" },
                    new SelectListItem { Text = "Punjabi", Value = "pa" },
                    new SelectListItem { Text = "Romanian", Value = "ro" },
                    new SelectListItem { Text = "Russian", Value = "ru" },
                    new SelectListItem { Text = "Serbian", Value = "sr" },
                    new SelectListItem { Text = "Sinhala", Value = "si" },
                    new SelectListItem { Text = "Slovak", Value = "sk" },
                    new SelectListItem { Text = "Slovenian", Value = "sl" },
                    new SelectListItem { Text = "Somali", Value = "so" },
                    new SelectListItem { Text = "Spanish", Value = "es" },
                    new SelectListItem { Text = "Spanish (Mexico)", Value = "es-MX" },
                    new SelectListItem { Text = "Swahili", Value = "sw" },
                    new SelectListItem { Text = "Swedish", Value = "sv" },
                    new SelectListItem { Text = "Tamil", Value = "ta" },
                    new SelectListItem { Text = "Telugu", Value = "te" },
                    new SelectListItem { Text = "Thai", Value = "th" },
                    new SelectListItem { Text = "Turkish", Value = "tr" },
                    new SelectListItem { Text = "Ukrainian", Value = "uk" },
                    new SelectListItem { Text = "Urdu", Value = "ur" },
                    new SelectListItem { Text = "Uzbek", Value = "uz" },
                    new SelectListItem { Text = "Vietnamese", Value = "vi" },
                    new SelectListItem { Text = "Welsh", Value = "cy" },

                };
                
               
                return View("Index", objInfo);
                
            }

                string content = string.Empty;
                string plainText = string.Empty;
                string fileExtension = System.IO.Path.GetExtension(objInfo.File.FileName);
                string TranslatedContent = string.Empty;
                // now AIGenerative has the value that user entered on form
                if (objInfo.File.Length > 0)
                {

                    using (var ms = new MemoryStream())
                    {
                        objInfo.File.CopyTo(ms);
                        var fileBytes = ms.ToArray();
                        string s = Convert.ToBase64String(fileBytes);
                         content = await analyzingImage(s, "", fileExtension);

                        var img = Pix.LoadFromMemory(fileBytes);
                        TesseractEngine eng = new TesseractEngine("./tessdata-4.0.0", "eng", EngineMode.Default);
                        Page page = eng.Process(img, PageSegMode.Auto);
                        plainText = page.GetText();



                    }


                    objInfo.ConvertedText = TranslateComment(content, objInfo.Language);


                }

                var model = new Translator
                {
                    ConvertedText = objInfo.ConvertedText,
                    FileName = objInfo.File.FileName.Substring(0, objInfo.File.FileName.Length - fileExtension.Length),
                    FullText = plainText,
                    language = objInfo.Language
                };

                return View(model);


            

            
        }

        [HttpPost]
        public IActionResult CreatePDF(Translator form, string Command)
        {
            string? convertedText = String.Empty;
            if (Command == "Summary")
            
                convertedText = form.ConvertedText;
            else
                convertedText = TranslateComment(form.FullText, form.language);
            
            var model = new SummaryPDF()
            {
                FileText = convertedText
            };

            return new Rotativa.AspNetCore.ViewAsPdf("showSummary",model);
        }
        async Task<string> analyzingImage(string file, string token, string fileExtension)
        {
            string? content = String.Empty;
            try
            {
             HttpClient client = new();

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                VisionRequest visionRequest = new(new List<ChatMessage>
                  {
                        new(new List<MessageContent>
                        {
                            new("text", "What's in this image?", null),
                            new("image_url", null, new ImageUrl($"data:image/{fileExtension};base64,{file}"))
                        })
                  });

                string json = JsonSerializer.Serialize(visionRequest, jsonOptions);

                HttpResponseMessage response = await client.PostAsync(completionsEndpoint, new StringContent(json, Encoding.UTF8, "application/json"));
                VisionResponse? visionResponse = await response.Content.ReadFromJsonAsync<VisionResponse>();
                content = visionResponse?.Choices?.FirstOrDefault()?.Message?.Content;

               
            }
            catch (Exception ex)
            {
                AnsiConsole.MarkupLine($"Something went wrong: [red]{ex.Message}[/]");
            }
            return content;
        }

        public string TranslateComment(string commentText, string targetLanguageCode)
        {
            var translate = new AmazonTranslateClient("AKIAU6GDZAOCUO7V2ZNQ", "TSZjHxxBmxEr1WnAjCEOZrdMSM0GDUAqnRISvsy7", RegionEndpoint.USEast1);
            var request = new TranslateTextRequest() { Text = commentText, SourceLanguageCode = "auto", TargetLanguageCode = targetLanguageCode };

            TranslateTextResponse TranslateResponse = translate.TranslateTextAsync(request).Result; // Make the actual call to Amazon Translate


            return TranslateResponse.TranslatedText;
        }


    }
}
