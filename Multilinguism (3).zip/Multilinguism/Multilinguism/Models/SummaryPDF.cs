﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Multilinguism.Models
{
    public class SummaryPDF
    {
        public string FileText { get; set; }
    }
}
